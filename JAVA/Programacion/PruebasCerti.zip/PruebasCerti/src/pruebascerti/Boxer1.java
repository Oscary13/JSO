/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pruebascerti;

/**
 *
 * @author Alien 2
 */
public class Boxer1 {
    Integer i;
    int x;
    
    public Boxer1(int y){
        x = i+y;
        System.out.println(x);
    }
    
    public static void main(String[] args) {
        new Boxer1(new Integer(4));
    }
}
