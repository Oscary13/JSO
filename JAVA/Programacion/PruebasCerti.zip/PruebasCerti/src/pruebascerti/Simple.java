package pruebascerti;

class Simple {
    public  float price;
    public static void main(String[] args) {
        Simple price = new Simple();
        price.price = 4;
    }
}
