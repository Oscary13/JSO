package com.digis01obb.OBasurtoProgramacionNCapasMaven;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OBasurtoProgramacionNCapasMavenApplication {

	public static void main(String[] args) {
		SpringApplication.run(OBasurtoProgramacionNCapasMavenApplication.class, args);
	}

}
