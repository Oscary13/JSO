/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.digis01obb.OBasurtoProgramacionNCapasMaven.ML;

/**
 *
 * @author Alien 2
 */
public class ResultExcel {
    public int row;
    public String errorMessage;

    public ResultExcel(int row, String errorMessage) {
        this.row = row;
        this.errorMessage = errorMessage;
    }
    
    
    
}
