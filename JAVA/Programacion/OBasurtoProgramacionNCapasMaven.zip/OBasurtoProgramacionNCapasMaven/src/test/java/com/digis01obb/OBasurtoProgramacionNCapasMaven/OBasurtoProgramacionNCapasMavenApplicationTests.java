package com.digis01obb.OBasurtoProgramacionNCapasMaven;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OBasurtoProgramacionNCapasMavenApplicationTests {

	@Test
	void contextLoads() {
	}

}
