package com.obbmoviedb.oBasurtoTheMovieDB;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OBasurtoTheMovieDbApplicationTests {

	@Test
	void contextLoads() {
	}

}
